package hoyocon.bomberman.EntitiesState;

public enum EntityType {
    PLAYER,
    ENEMY,
    WALL,
    BRICK,
    BOMB,
    EXPLOSION,
    BUFF,
    NONE
}
