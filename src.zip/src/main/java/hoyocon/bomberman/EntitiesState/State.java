package hoyocon.bomberman.EntitiesState;

public enum State {
    IDLE, UP, DOWN, LEFT, RIGHT, DEAD, BURNED, GHOST
}
