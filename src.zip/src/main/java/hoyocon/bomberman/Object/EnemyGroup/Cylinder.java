package hoyocon.bomberman.Object.EnemyGroup;

public class Cylinder extends Enemy {

    public Cylinder() {
        super(0, 0, 100, "enemy4.png"); // x=0, y=0 khởi tạo mặc định
    }

}