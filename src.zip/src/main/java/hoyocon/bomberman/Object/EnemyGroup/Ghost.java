package hoyocon.bomberman.Object.EnemyGroup;

public class Ghost extends Enemy {

    public Ghost() {
        super(0, 0, 100, "enemy5.png"); // x=0, y=0 khởi tạo mặc định
    }

}
