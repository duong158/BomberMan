package hoyocon.bomberman.Object.EnemyGroup;

/**
 * Quái vật Slime - có khả năng di chuyển ngẫu nhiên và nhảy
 */
public class Slime extends Enemy {
    public Slime(int x, int y) {
        super(x, y, 80, "/assets/textures/enemy5.png");

    }
}